<?php
/*MOBILE CONFIG*/

/* only for full version */

$enableMobile = true; // enable mobile version of template
$redirectPhone = true; // redirect phones
$redirectTablet = false; //redirect tablets

$groupSpacing_mob = array(4.5,3.5,3.5);

$mobileZoomable = false; // enable pinch-to-zoom or not?
$showFullSiteLink = true; // show link to full site in footer of mobile site

?>