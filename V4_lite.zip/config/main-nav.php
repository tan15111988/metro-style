<a rel="group0">
	<img src="img/icons/home.png" alt="home"/>
	Home
</a>
<a rel="group1">
	<img src="img/icons/download_s.png" alt="Tilegroup 2"/>
	Tilegroup 2
 </a>
<a rel="group2">
	<img src="img/icons/questionmark.png" alt="Group 3"/>
	Group 3
</a>