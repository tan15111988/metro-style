<?php
$subNav = array(
	"Welcome ; welcome.php ; #509601;",
	"Accordions ; accordions.php ; #509601;",
	"Sidebars ; sidebars.php ; #509601;",
);

set_include_path("../");
include("inc/essentials.php");
?>
<script>
$mainNav.set("home") // this line colors the top button main nav with the text "home"
</script>
<h1 class="margin-t-0">Welcome</h1>
<hr>
<h3>First page</h3>
<p>Thanks for downloading this template! This is your first subpage.
<p>Please read the <a href="http://metro-webdesign.info/#!/docs-and-tutorials">Tutorials</a> and try to modify the code.
<h3>Having a problem?</h3>
<p>You can ask for help on the <a href="http://metro-webdesign.info/forum/">forum</a>.

<p class="margin-t-40">Thanks and best regards, Thomas